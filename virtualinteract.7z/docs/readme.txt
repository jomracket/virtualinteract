Turn Word Wrap ON if you're using Notepad.

Virtual Interact for Windows95/98, by James the Animal Tamer.

HOME PAGE:
==========
www.geocities.com/emucompboy
Home of the Virtual Aquarius

CONTACT:
========
emucompboy@yahoo.com

NOTE to ROM IMAGE COLLECTORS:
=============================
Howdy.  I'd prefer you reference my website, rather than putting my files up for download on your site.  These emulators are works in progress, and I will randomly be updating them.  Now, you wouldn't want to have an inferior version on your website, would you?
	Thanks.

System Requirements:
====================
Fast system, Celeron 400MHz or equivalent recommended
Windows95/98
DirectX
16-bit video card (Virtual Interact will work in other modes, but may be slow or not look right)
Sound card compatible with DirectX


Known Bugs
==========
1.  There is no sound.
2.  It's not running at the right speed.
3.  The cassette loading is ROM-patched (a form of cheating)
4.  Joysticks don't work.  The numeric keypad is both joysticks, with the numeric keypad - and numeric keypad + keys serving to emulate the potentiometer knob.
5.  You must configure the printer filename before trying to LPRINT or LLIST or COPY.  Not that those work anyway.
6.  Most things don't work.  This is a very early version of the emulator.



Preliminary Note:
=================
Here's Virtual Aquarius version 0.01.  The low number indicates that it's barely working, and missing key features/conveniences.

An important feature for BASIC programmers is Quicktype (from the file menu).  This automatically types a text file.  The best way to use this is to edit a BASIC program as a text file using NOTEPAD.  Save it (from NOTEPAD).  Then use Quicktype to load it into the Virtual Interact.  This is much easier than trying to type in a program on the Virtual Interact itself, especially seeing as how there's no way of saving from the emulator at present.

Also, a peculiarity of Interact's Microsoft Level II BASIC is that you MUST type a NEW command before starting to enter your program!!




What works:
=====================
Nothing works well


What sort of works:
=====================
CPU (The real computer has an 8080a, but the emulator still has a z80)
Memory (with configuration)
Keyboard (emulated and sensible;  canNOT be configured)
Video (Colors can be configured)
Quicktype (provides a means of loading in BASIC programs from text files)
Character set (there isn't any, so it works GREAT)
Joystick (both are mapped to the numeric keypad, 8 4 6 2, with 0 being the fire button, and - + working the potentiometer knob)
Window size configuration


What does NOT work:
=====================
Optional loading of other ROM OS
Sound (mostly working)
Video border (can be optionally turned off)
Accurate timing (close enough, or configure your own)
Insertion/removal of game cartridges (you need to Hard Reset to start the cartridge)
BASIC CLOAD (CAQ files;  partial support for raw WAV files)
BASIC CSAVE (CAQ files)
LPRINT/LLIST/COPY (To file.  Note that COPY isn't useful -- SORRY! -- use Windows to Printscreen instead.)
Insertion/removal of BASIC expansion cartridges
Insertion/removal of CP/M cartridges
Timers (if any)
Interrupts (if any)
Other peripherals (hey, I've never even SEEN the Aquarius disk drive!)


What will NEVER work:
=====================
Modem or other RS-232c interface
Any peripheral I can't analyze
Pokemon (sorry, that's for the GAME BOY)


Still left to be done:
======================
Pretty much everything


NOTES:
=====================
1.  Joysticks.  (both are mapped to the numeric keypad, 8 4 6 2, with 0 being the fire button, and - + working the potentiometer knob)

2.  Sound.  It doesn't work.

3.  Keyboard.  The keyboard operates in one of two modes:  Emulated or Sensible.  Emulated mode is most like the real Interact keyboard;  use this mode for playing games.  Sensible makes it easier to type from the PC keyboard.  You can switch back and forth in the same session.

4.  CLOAD.  You can't.  It doesn't work yet.  Type your BASIC programs in Notepad, and use Quicktype from the file menu to enter them.  Make sure the first line of that .txt file is NEW.

5.  Game cartridges.  There aren't any.





Versions:
=========

December 2002: 0.01		(Sent up to Internet, Feb 2003)
	First working version, including Quicktype, keyboard, memory, ROM patch loading of cassette software


Credits
=======
Me (James the Animal Tamer) -- Everything that's not mentioned separately below

Z80Em:		Portable Z80 emulator Copyright (C) Marcel de Kogel 1996,1997
	(I grabbed this from MAME)

ay8910.c	From MAME, credited to Ville Hallik, Michael Cuddy,Tatsuyuki Satoh, Fabrice Frances, Nicola Salmoria.

Microsoft	DirectX, Microsoft Visual C++, Microsoft Development Studio, Windows 95/98.  Thanks, Bill.

ROMs and some .CIN files:	See those for their respective credits.

