If you're using Notepad, turn on wordwrap.

These .CIN files are Interact-format cassette files.

To use them, hard reset the Virtual Interact emulator, and press L when prompted to do so.  A file requester will appear.  Select the .CIN file you want.

