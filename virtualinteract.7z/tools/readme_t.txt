Turn Word Wrap ON if you're using Notepad.

Tools for use with Virtual Aquarius for Windows95/98, by James the Animal Tamer.

NOTE to ROM IMAGE COLLECTORS:
=============================
Howdy.  I'd prefer you reference my website, rather than putting my files up for download on your site.  These emulators are works in progress, and I will randomly be updating them.  Now, you wouldn't want to have an inferior version on your website, would you?
	Thanks.

HOME PAGE:
==========
www.geocities.com/emucompboy
Home of the Virtual Aquarius

CONTACT:
========
emucompboy@yahoo.com




Okay, here's the goods:

You'll find two tools here.  They are very much preliminary.  They are so preliminary that I've never run them in RELEASE mode (which is the version collected here).  Use them at your own risk.  If there's a problem, let me know, and maybe I'll fix it.  Then again, maybe I won't.  After all, the debug versions I use work fine for me!


CLIPWAV.EXE
==========
This is a program which "clips" a wave file.  The input must be 8-bit, mono, 44,100 samples per second, and is presumably a cassette save file which you've digitized.  The wave file must also be symmetrical around its middle.

Why would you want to "clip" a wave?  A wave file so processed zips up a whole lot better than a raw wave file, which means you can put more of them on your website without getting a bandwidth notice from your Internet host.  

To use CLIPWAV, double click the icon.
Click on BROWSE and go find your input WAV file.

The output file is name_C.WAV, if name.WAV was your input file.  It is placed in the same directory as your input file.



CIN2WAV.EXE
===========
This program converts a .CIN file to a .WAV file which can be played back to a real Interact computer.  There's nothing to it.  Click on BROWSE to find your input file.  It'll process for a few seconds.  The output file is name_Q.WAV if your file was named name.CIN.  It is placed in the same directory as your input file.
