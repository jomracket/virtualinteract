Turn Word Wrap ON if you're using Notepad.

See also the readme.txt in the docs directory.

This is the Quick Start document.

First, unzip all the files into a directory, e.g. c:\VInteract.

Cool.

Then double-click on the VInter.exe icon.

The emulator should now be running.

Press the L key because it tells you to!

Select one of the .CIN files.

Enjoy.

==

If you selected basic_lii.CIN, then you can Quickype a BASIC program!

From the file menu, select Quick Type..., and from the quicktyp directory, open americanflag.txt.

type run

Admire the flag!

Hit Control C when you're tired of looking at the flag.

==

After you've watched the flag, go and read the readme.txt that's in the DOCS directory!

You can Quicktype other program text files too.


Enjoy!
James the Animal Tamer
2003
www.geocities.com/emucompboy

